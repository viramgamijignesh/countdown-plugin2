<?php 
/*
Plugin Name: Logicrays WP Product Count Down
Plugin URI: http://www.logicrays.com/
Description: A full-featured WordPress count down plugin .
Author: LogicRays WordPress Team
Version: 1.0
*/

define('lr_count_down_product_path', plugins_url('', __FILE__).'/assets');

	
// First Register the Tab by hooking into the 'woocommerce_product_data_tabs' filter
add_filter( 'woocommerce_product_data_tabs', 'lr_count_down_product_tab' );
function lr_count_down_product_tab( $product_data_tabs ) {
    $product_data_tabs['my-custom-tab'] = array(
        'label' => __( 'Product CountDown', 'woocommerce' ),
        'target' => 'lr_count_down_product_data',
        'class'     => array( 'show_if_simple' ),
    );
    return $product_data_tabs;
}

/** CSS To Add Custom tab Icon */
function lr_admin_count_down_product_style() {
	
	wp_enqueue_style('lr_jquery_datetimepicker_css', lr_count_down_product_path.'/css/jquery.datetimepicker.css');
	
	wp_enqueue_script('lr_jquery_datetimepicker_js',lr_count_down_product_path.'/js/jquery.datetimepicker.full.js');	
	
	wp_enqueue_script('lr_lr_admin_custom_js',lr_count_down_product_path.'/js/lr_admin_custom.js');
	
?>
<style>
#woocommerce-product-data ul.wc-tabs li.my-custom-tab_options a:before { font-family: WooCommerce; content: "\e012"; }
</style>
<?php 
}
add_action( 'admin_enqueue_scripts', 'lr_admin_count_down_product_style' ); // admin js and css file

add_action('wp_enqueue_scripts', 'lr_front_count_down_product_style'); // front-end js and css file
function lr_front_count_down_product_style() {
	
	wp_enqueue_script('lr_jquery-2_0_3_js',lr_count_down_product_path.'/js/jquery-2.0.3.js');
	
	wp_enqueue_style('lr_front_counter_css',lr_count_down_product_path.'/css/lr_front_counter.css');
}
// functions you can call to output text boxes, select boxes, etc.
add_action('woocommerce_product_data_panels', 'lr_count_down_product_data_fields');

function lr_count_down_product_data_fields() {
    global $post;

    // Note the 'id' attribute needs to match the 'target' parameter set above
    ?> 	<div id = 'lr_count_down_product_data'
    class = 'panel woocommerce_options_panel' > <?php
        ?> 	<div class = 'options_group' > <?php
			  // Checkbox
			  woocommerce_wp_checkbox(
				array(
				  'id' => '_lr_checkbox',
				  'label' => __('Enable', 'woocommerce' ),
				  'description' => __( 'Enable LR WooCommerce Product Countdown for this product!', 'woocommerce' )
				)
			  );
						  // Text Field
			  woocommerce_wp_text_input(
				array(
				  'id' => '_lr_sale_price_from',
				  'label' => __( 'Count Down Data From', 'woocommerce' ),
				  'wrapper_class' => 'show_if_simple', //show_if_simple or show_if_variable
				  'placeholder' => 'Enter Count Down From Date',
				  'desc_tip' => 'true',
				  'description' => __( 'Sell Start Date.', 'woocommerce' )
				)
			  );
				
			  woocommerce_wp_text_input(
				array(
				  'id' => '_lr_sale_price_to',
				  'label' => __( 'Count Down Data To', 'woocommerce' ),
				  'wrapper_class' => 'show_if_simple', //show_if_simple or show_if_variable
				  'placeholder' => 'Enter Count Down To Date',
				  'desc_tip' => 'true',
				  'description' => __( 'Sell End Date.', 'woocommerce' )
				)
			  );
			?> 
			</div>

		</div>
	<?php
}

/** Hook callback function to save custom fields information */
function lr_count_down_product_custom_fields($post_id) {
	
	// Save Checkbox
    $_lr_checkbox = isset($_POST['_lr_checkbox']) ? 'yes' : 'no';
    update_post_meta($post_id, '_lr_checkbox', $_lr_checkbox);
	
	
    $_lr_sale_price_from = $_POST['_lr_sale_price_from'];
    if (!empty($_lr_sale_price_from)) {
        update_post_meta($post_id, '_lr_sale_price_from', esc_attr($_lr_sale_price_from));
    }

	$_lr_sale_price_to = $_POST['_lr_sale_price_to'];
    if (!empty($_lr_sale_price_to)) {
        update_post_meta($post_id, '_lr_sale_price_to', esc_attr($_lr_sale_price_to));
    }   

}

add_action( 'woocommerce_process_product_meta_simple', 'lr_count_down_product_custom_fields'  );

// You can uncomment the following line if you wish to use those fields for "Variable Product Type"
add_action( 'woocommerce_process_product_meta_variable', 'lr_count_down_product_custom_fields'  );

function activate_wp_lr_feedback_plugin() {	
	
	$posts = get_posts(array(
		'post_type'   => 'product',
		'post_status' => 'publish',
		'posts_per_page' => -1,
		'fields' => 'ids'
		)
	);
	//loop over each post
	foreach($posts as $p){
		//get the meta you need form each post
		$to_date = get_post_meta($p,"_lr_sale_price_to",true);
		$from_date = get_post_meta($p,"_lr_sale_price_from",true);
		$enable = get_post_meta($p,"_lr_checkbox",true);
		//do whatever you want with it
		
		
	}
	?>
	<input type="hidden" id="first" value=<?php echo $from_date;?> />
	<input type="hidden" id="second" value=<?php echo $to_date;?>/>
	
	<script>
		var timer;

		var compareDate = new Date('<?php echo $from_date; ?>')
		var to_date = new Date('<?php echo $to_date; ?>')
		var get_to_date = to_date.getDate();
		compareDate.setDate(compareDate.getDate() + get_to_date); //just for this demo today + 7 days

		timer = setInterval(function() {
		  timeBetweenDates(compareDate);
		}, 1000);

		function timeBetweenDates(toDate) {
		  var dateEntered = toDate;
		  var now = new Date();
		  var difference = dateEntered.getTime() - now.getTime();

		  if (difference <= 0) {

			// Timer done
			clearInterval(timer);
		  
		  } else {
			
			var seconds = Math.floor(difference / 1000);
			var minutes = Math.floor(seconds / 60);
			var hours = Math.floor(minutes / 60);
			var days = Math.floor(hours / 24);

			hours %= 24;
			minutes %= 60;
			seconds %= 60;

			$("#countdown-days").text(days);
			$("#countdown-hours").text(hours);
			$("#countdown-minutes").text(minutes);
			$("#countdown-seconds").text(seconds);
		  }
		}
	</script>	
	
    <span id="given_date"></span>
	<header id="sticky-nav-header">
		<div id="scarcity" class="header-section">
		<div id="sale-ends">
			<div id="sale-ends-text">Sale Ends In</div>
			<div id="sale-ends-countdown">
				<span class="countdown-item" id="countdown-days" data-label="DAYS"></span>
				<span class="countdown-item" id="countdown-hours" data-label="HOURS"></span>
				<span class="countdown-item" id="countdown-minutes" data-label="MINS"></span>
				<span class="countdown-item" id="countdown-seconds" data-label="SECS"></span>
			</div>
		</div>
	</div>
		<div id="header-cta" class="header-section">
		<button type="button" class="button cta-button">Claim Coupon</button>
	</div>
	</header>
	
	<?php

}

add_shortcode( 'LR_FEEDBACK', 'activate_wp_lr_feedback_plugin' );
?>
<div class="optin" style="">
		<div class="close"><svg class="nc-icon glyph icon-no " xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="16px" height="16px" viewBox="0 0 16 16"><g>
				<path fill="#000000" d="M14.7,1.3c-0.4-0.4-1-0.4-1.4,0L8,6.6L2.7,1.3c-0.4-0.4-1-0.4-1.4,0s-0.4,1,0,1.4L6.6,8l-5.3,5.3
					c-0.4,0.4-0.4,1,0,1.4C1.5,14.9,1.7,15,2,15s0.5-0.1,0.7-0.3L8,9.4l5.3,5.3c0.2,0.2,0.5,0.3,0.7,0.3s0.5-0.1,0.7-0.3
					c0.4-0.4,0.4-1,0-1.4L9.4,8l5.3-5.3C15.1,2.3,15.1,1.7,14.7,1.3z"></path>
				</g></svg></div>
		<div class="headline">Claim Your Coupon</div>
		<div class="content">Enter your details below to claim your coupon.</div>
					<div class="error" style="display: none;" id="fname-error"><svg class="nc-icon glyph icon-error " xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="16px" height="16px" viewBox="0 0 16 16"><g>
				<path fill="#ed6347" d="M8,0C3.6,0,0,3.6,0,8s3.6,8,8,8s8-3.6,8-8S12.4,0,8,0z M8,12c-0.6,0-1-0.4-1-1s0.4-1,1-1s1,0.4,1,1
					S8.6,12,8,12z M9,9H7V4h2V9z"></path>
				</g></svg>Please enter your first name</div>
			<input id="fname-input" type="text" placeholder="First name">
						<div class="optin-icon"><svg class="nc-icon glyph icon-person " xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="16px" height="16px" viewBox="0 0 16 16"><g><path fill="#000000" d="M8,9L8,9C5.8,9,4,7.2,4,5V4c0-2.2,1.8-4,4-4h0c2.2,0,4,1.8,4,4v1C12,7.2,10.2,9,8,9z"></path>
				<path data-color="color-2" fill="#000000" d="M10,11H6c-2.8,0-5,2.2-5,5v0h14v0C15,13.2,12.8,11,10,11z"></path></g></svg></div>
				<div class="error" style="display: none;" id="email-error"><svg class="nc-icon glyph icon-error " xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="16px" height="16px" viewBox="0 0 16 16"><g>
				<path fill="#ed6347" d="M8,0C3.6,0,0,3.6,0,8s3.6,8,8,8s8-3.6,8-8S12.4,0,8,0z M8,12c-0.6,0-1-0.4-1-1s0.4-1,1-1s1,0.4,1,1
					S8.6,12,8,12z M9,9H7V4h2V9z"></path>
				</g></svg>Please enter a valid email address</div>
		<input id="email-input" type="email" placeholder="Email address">
				<div class="optin-icon"><svg class="nc-icon glyph icon-email " xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="16px" height="16px" viewBox="0 0 16 16"><g>
				<path data-color="color-2" fill="#000000" d="M15,1H1C0.4,1,0,1.4,0,2v1.4l8,4.5l8-4.4V2C16,1.4,15.6,1,15,1z"></path>
				<path fill="#000000" d="M7.5,9.9L0,5.7V14c0,0.6,0.4,1,1,1h14c0.6,0,1-0.4,1-1V5.7L8.5,9.9C8.22,10.04,7.78,10.04,7.5,9.9z"></path>
				</g></svg></div>
				<button id="optin-submit" type="button" class="button">Claim My Coupon</button>
		<img  style="margin: 0 auto;" width="160" height="77" src="https://278ntz321mzx43cdt332nz2h-wpengine.netdna-ssl.com/wp-content/themes/landingcube/amazon-logo_transparent-2x.png"><p id="privacy" class="content-editable content-editable-html">
		</p>
		
	</div>
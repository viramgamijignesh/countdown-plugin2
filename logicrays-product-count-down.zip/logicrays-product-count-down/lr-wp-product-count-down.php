<?php 
/*
Plugin Name: Logicrays WP Product Count Down
Plugin URI: http://www.logicrays.com/
Description: A full-featured WordPress count down plugin .
Author: LogicRays WordPress Team
Version: 1.0
*/

define('lr_count_down_product_path', plugins_url('', __FILE__).'/assets');

	
// First Register the Tab by hooking into the 'woocommerce_product_data_tabs' filter
add_filter( 'woocommerce_product_data_tabs', 'lr_count_down_product_tab' );
function lr_count_down_product_tab( $product_data_tabs ) {
    $product_data_tabs['my-custom-tab'] = array(
        'label' => __( 'Product CountDown', 'woocommerce' ),
        'target' => 'lr_count_down_product_data',
        'class'     => array( 'show_if_simple' ),
    );
    return $product_data_tabs;
}

/** CSS To Add Custom tab Icon */
function lr_admin_count_down_product_style() {
	
	wp_enqueue_style('lr_jquery_datetimepicker_css', lr_count_down_product_path.'/css/jquery.datetimepicker.css');
	
	wp_enqueue_script('lr_jquery_datetimepicker_js',lr_count_down_product_path.'/js/jquery.datetimepicker.full.js');	
	
	wp_enqueue_script('lr_lr_admin_custom_js',lr_count_down_product_path.'/js/lr_admin_custom.js');
	
?>
<style>
#woocommerce-product-data ul.wc-tabs li.my-custom-tab_options a:before { font-family: WooCommerce; content: "\e012"; }
</style>
<?php 
}
add_action( 'admin_enqueue_scripts', 'lr_admin_count_down_product_style' ); // admin js and css file

add_action('wp_enqueue_scripts', 'lr_front_count_down_product_style'); // front-end js and css file
function lr_front_count_down_product_style() {
	
	wp_enqueue_script('lr_jquery-2_0_3_js',lr_count_down_product_path.'/js/jquery-2.0.3.js');
	
	wp_enqueue_style('lr_front_counter_css',lr_count_down_product_path.'/css/lr_front_counter.css');
}
// functions you can call to output text boxes, select boxes, etc.
add_action('woocommerce_product_data_panels', 'lr_count_down_product_data_fields');

function lr_count_down_product_data_fields() {
    global $post;

    // Note the 'id' attribute needs to match the 'target' parameter set above
    ?> 	<div id = 'lr_count_down_product_data'
    class = 'panel woocommerce_options_panel' > <?php
        ?> 	<div class = 'options_group' > <?php
			  // Checkbox
			  woocommerce_wp_checkbox(
				array(
				  'id' => '_lr_checkbox',
				  'label' => __('Enable', 'woocommerce' ),
				  'description' => __( 'Enable LR WooCommerce Product Countdown for this product!', 'woocommerce' )
				)
			  );
						  // Text Field
			  woocommerce_wp_text_input(
				array(
				  'id' => '_lr_sale_price_from',
				  'label' => __( 'Count Down Data From', 'woocommerce' ),
				  'wrapper_class' => 'show_if_simple', //show_if_simple or show_if_variable
				  'placeholder' => 'Enter Count Down From Date',
				  'desc_tip' => 'true',
				  'description' => __( 'Sell Start Date.', 'woocommerce' )
				)
			  );
				
			  woocommerce_wp_text_input(
				array(
				  'id' => '_lr_sale_price_to',
				  'label' => __( 'Count Down Data To', 'woocommerce' ),
				  'wrapper_class' => 'show_if_simple', //show_if_simple or show_if_variable
				  'placeholder' => 'Enter Count Down To Date',
				  'desc_tip' => 'true',
				  'description' => __( 'Sell End Date.', 'woocommerce' )
				)
			  );
			?> 
			</div>

		</div>
	<?php
}

/** Hook callback function to save custom fields information */
function lr_count_down_product_custom_fields($post_id) {
	
	// Save Checkbox
    $_lr_checkbox = isset($_POST['_lr_checkbox']) ? 'yes' : 'no';
    update_post_meta($post_id, '_lr_checkbox', $_lr_checkbox);
	
	
    $_lr_sale_price_from = $_POST['_lr_sale_price_from'];
    if (!empty($_lr_sale_price_from)) {
        update_post_meta($post_id, '_lr_sale_price_from', esc_attr($_lr_sale_price_from));
    }

	$_lr_sale_price_to = $_POST['_lr_sale_price_to'];
    if (!empty($_lr_sale_price_to)) {
        update_post_meta($post_id, '_lr_sale_price_to', esc_attr($_lr_sale_price_to));
    }   

}

add_action( 'woocommerce_process_product_meta_simple', 'lr_count_down_product_custom_fields'  );

// You can uncomment the following line if you wish to use those fields for "Variable Product Type"
add_action( 'woocommerce_process_product_meta_variable', 'lr_count_down_product_custom_fields'  );

function activate_wp_lr_feedback_plugin() {	
	
	$posts = get_posts(array(
		'post_type'   => 'product',
		'post_status' => 'publish',
		'posts_per_page' => -1,
		'fields' => 'ids'
		)
	);
	//loop over each post
	foreach($posts as $p){
		//get the meta you need form each post
		$to_date = get_post_meta($p,"_lr_sale_price_to",true);
		$from_date = get_post_meta($p,"_lr_sale_price_from",true);
		$enable = get_post_meta($p,"_lr_checkbox",true);
		//do whatever you want with it
		
		
	}
	?>
	<input type="hidden" id="first" value=<?php echo $from_date;?> />
	<input type="hidden" id="second" value=<?php echo $to_date;?>/>
	
	<script>
		var timer;

		var compareDate = new Date('<?php echo $from_date; ?>')
		var to_date = new Date('<?php echo $to_date; ?>')
		var get_to_date = to_date.getDate();
		compareDate.setDate(compareDate.getDate() + get_to_date); //just for this demo today + 7 days

		timer = setInterval(function() {
		  timeBetweenDates(compareDate);
		}, 1000);

		function timeBetweenDates(toDate) {
		  var dateEntered = toDate;
		  var now = new Date();
		  var difference = dateEntered.getTime() - now.getTime();

		  if (difference <= 0) {

			// Timer done
			clearInterval(timer);
		  
		  } else {
			
			var seconds = Math.floor(difference / 1000);
			var minutes = Math.floor(seconds / 60);
			var hours = Math.floor(minutes / 60);
			var days = Math.floor(hours / 24);

			hours %= 24;
			minutes %= 60;
			seconds %= 60;

			$("#countdown-days").text(days);
			$("#countdown-hours").text(hours);
			$("#countdown-minutes").text(minutes);
			$("#countdown-seconds").text(seconds);
		  }
		}
	</script>	
	
    <span id="given_date"></span>
	<header id="sticky-nav-header">
		<div id="scarcity" class="header-section">
		<div id="sale-ends">
			<div id="sale-ends-text">Sale Ends In</div>
			<div id="sale-ends-countdown">
				<span class="countdown-item" id="countdown-days" data-label="DAYS"></span>
				<span class="countdown-item" id="countdown-hours" data-label="HOURS"></span>
				<span class="countdown-item" id="countdown-minutes" data-label="MINS"></span>
				<span class="countdown-item" id="countdown-seconds" data-label="SECS"></span>
			</div>
		</div>
	</div>
		<div id="header-cta" class="header-section">
		<button type="button" class="button cta-button">Claim Coupon</button>
	</div>
	</header>
	
	<?php

}

add_shortcode( 'LR_FEEDBACK', 'activate_wp_lr_feedback_plugin' );